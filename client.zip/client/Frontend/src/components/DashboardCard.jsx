/* eslint-disable react/prop-types */
// eslint-disable-next-line no-unused-vars
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const DashboardCard = ({ title, value, percentage }) => {
  const cardClass = percentage >= 0 ? 'text-success' : 'text-danger';
  const iconClass = percentage >= 0 ? 'bi-arrow-up' : 'bi-arrow-down';

  return (
    <div className="card text-center mx-1 my-2 shadow-sm">
      <div className="card-body">
        <h6 className="card-subtitle mb-2 text-muted">{title}</h6>
        <h5 className="card-title">{value}</h5>
        <div className={`${cardClass}`}>
          <i className={`${iconClass}`}></i> {Math.abs(percentage)}%
        </div>
      </div>
    </div>
  );
};

export default DashboardCard;