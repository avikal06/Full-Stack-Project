/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */
// eslint-disable-next-line no-unused-vars
import React, { Component } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import HC_options from "highcharts/modules/exporting";
import HC_export from "highcharts/modules/export-data";
import { Table, Button, Card} from 'antd';
import * as Icon from 'react-bootstrap-icons';
// import {SalesBox} from './SalesBox'
// import {DashboardCard} from './DashboardCard'
    


const trafficData = [
    { source: 'Direct', value: 143382 },
    { source: 'Referral', value: 87974 },
    { source: 'Social Media', value: 45211 },
    { source: 'Twitter', value: 21893 }
  ];

  const maxValue = Math.max(...trafficData.map(item => item.value));

const customers = [
    { name: 'Jenny Wilson', email: 'w.lawson@example.com', city: 'Austin', amount: '$11,234' },
    { name: 'Devon Lane', email: 'dat.roberts@example.com', city: 'New York', amount: '$11,159' },
    { name: 'Jane Cooper', email: 'jgraham@example.com', city: 'Toledo', amount: '$10,483' },
    { name: 'Dianne Russell', email: 'curtis.d@example.com', city: 'Naperville', amount: '$9,084' },
  ];


const data = [
    {
        key: '1',
        state: 'Complete',
        paymentMethod: 'Card',
        value: 100,
        date: '1 Jan 2024',
        platform: 'Amazon',
    },
    {
        key: '2',
        state: 'Complete',
        paymentMethod: 'Card',
        value: 50,
        date: '1 Jan 2024',
        platform: 'Netflix',
    },
    {
        key: '3',
        state: 'Canceled',
        paymentMethod: 'Card',
        value: 75,
        date: '1 Jan 2024',
        platform: 'Facebook',
    },
    {
        key: '4',
        state: 'Pending',
        paymentMethod: 'Card',
        value: 120,
        date: '1 Jan 2024',
        platform: 'Amazon Prime',
    },
];

const columns = [
    {
        title: 'State',
        dataIndex: 'state',
        render: (text) => {
            let color;
            if (text === 'Complete') {
                color = 'green';
            } else if (text === 'Canceled') {
                color = 'red';
            } else if (text === 'Pending') {
                color = 'yellow';
            }
            return <span style={{ color }}>{text}</span>;
        },
    },
    {
        title: 'Payment Method',
        dataIndex: 'paymentMethod',
    },
    {
        title: 'Value ($)',
        dataIndex: 'value',
    },
    {
        title: 'Date',
        dataIndex: 'date',
    },
    {
        title: 'Platform',
        dataIndex: 'platform',
    },
    {
        title: '',
        dataIndex: '',
        render: () => <Button type="link">...</Button>,
    },
];

class home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chartOptions: this.generateChartOptions('12m')
        };
    }
    componentDidMount() {
        HC_options(Highcharts);
        HC_export(Highcharts);
    }
    componentDidUpdate(){
        HC_options(Highcharts);
        HC_export(Highcharts);
    }
    generateChartOptions = (timeRange) => {
        let numDataPoints;
        let xAxisCategories = [];
        switch (timeRange) {
            case '6m':
                numDataPoints = 6;
                xAxisCategories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
                break;
            case '30d':
                numDataPoints = 30;
                xAxisCategories = Array.from({ length: 30 }, (_, i) => `Day ${i + 1}`);
                break;
            case '7d':
                numDataPoints = 7;
                xAxisCategories = Array.from({ length: 7 }, (_, i) => `Day ${i + 1}`);
                break;
            case '12m':
            default:
                numDataPoints = 12;
                xAxisCategories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                break;
        }

        const fakeSalesData = Array.from({ length: numDataPoints }, (_, i) => {
            const baseSales = Math.sin(i * Math.PI / 6) * 500 + 500;
            const randomNoise = Math.random() * 200 - 100;
            return baseSales + randomNoise;
        });

        const fakeProfitData = Array.from({ length: numDataPoints }, (_, i) => {
            // Generate a rising trend for profit
            return i * 100 + 500;
        });

        return {
            chart: {
                type: 'line',
                marginLeft: 100
            },
            title: {
                text: 'Sales Report',
                align: 'left',
                x: 100
            },
            xAxis: {
                categories: xAxisCategories,
                title: {
                    text: 'Time'
                }
            },
            yAxis: {
                title: {
                    text: 'Amount'
                }
            },
            series: [{
                name: 'Sales',
                data: fakeSalesData
            }, {
                name: 'Total Profit',
                data: fakeProfitData
            }],
            exporting: {
                enabled: true,
                buttons: {
                    contextButton: {
                        menuItems: ['downloadPDF']
                    }
                }
            },
            credits: {
                enabled: false
            }
        };
    }

    handleTimeRangeChange = (timeRange) => {
        const newChartOptions = this.generateChartOptions(timeRange);
        this.setState({ chartOptions: newChartOptions });
    }



    render() {
        return (
            <div className='Main-Comp'>
                <div className='row'>
                    <strong>Hey Mariana - <span className='ml-2 des'>here's what's happening with your store today</span> </strong>
                </div>
                <div className='row first-comp mt-3 col-11'>
                {/* <DashboardCard title="TODAY'S SALE" value="$12,426" percentage={3.6} />
<DashboardCard title="TOTAL SALES" value="$2,38,485" percentage={1.4} />
<DashboardCard title="TOTAL ORDERS" value="84,382" percentage={3.6} />
<DashboardCard title="TOTAL CUSTOMERS" value="33,493" percentage={3.6} /> */}
                </div>
                <div className='row mt-4'>
                    <div className='col-8 time'>
                        <div className='row justify-content-end mt-2'>
                            <button className='col-2 btn-des' onClick={() => this.handleTimeRangeChange('12m')}>12 Months</button>
                            <button className='col-2 btn-des' onClick={() => this.handleTimeRangeChange('6m')}>6 Months</button>
                            <button className='col-2 btn-des' onClick={() => this.handleTimeRangeChange('30d')}>30 Days</button>
                            <button className='col-2 btn-des' onClick={() => this.handleTimeRangeChange('7d')}>7 Days</button>
                        <HighchartsReact
                            highcharts={Highcharts}
                            options={this.state.chartOptions}
                        />
                        </div>
                    </div>
                    <div className='col-4'>
                    <div className="traffic-sources p-3 bg-white rounded shadow-sm">
      <h6 className="font-weight-bold text-uppercase mb-3">Traffic Sources</h6>
      <div className="mb-2 text-muted">Last 7 Days</div>
      {trafficData.map((data, index) => (
        <div key={index} className="mb-3">
          <div className="d-flex justify-content-between mb-1">
            <span>{data.source}</span>
            <span>{data.value.toLocaleString()}</span>
          </div>
          <div className="progress" style={{ height: '20px' }}>
            <div
              className="progress-bar"
              role="progressbar"
              style={{ width: `${(data.value / maxValue) * 100}%`}}
              aria-valuenow={data.value}
              aria-valuemin="0"
              aria-valuemax={maxValue}
            />
          </div>
        </div>
      ))}
    </div>
                    </div>
                </div>
                <div className='row mt-4'>
                    <div className='col-8 time'>
                        <div className='mt-2' style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                            <h2>Transactions</h2>
                            <div>
                                <Button type="text">See All Transactions
                                    <Icon.ChevronRight className='ml-2' size={'1.25rem'} />
                                </Button>

                            </div>
                        </div>
                        <Table dataSource={data} columns={columns} showHeader={false} />
                    </div>
                    <div className='col-4'>
                    <Card title="Recent Customers" bordered={false} className="recent-customers">
      <p>Lorem ipsum dolor sit ametis.</p>
      <ul className="list-group">
        {customers.map((customer, index) => (
          <li className="list-group-item" key={index}>
            <div className="customer-info">
              <div className="fw-bold">{customer.name}</div>
              {customer.email}
            </div>
            <div className="customer-details">
              <span>{customer.city}</span>
              <span className="badge">{customer.amount}</span>
            </div>
          </li>
        ))}
      </ul>
      <a href="#" className="card-link">See all customers</a>
    </Card>
                    </div>
                </div>
            </div>
        );
    }
}

export default home;
