const mongoose = require("mongoose");

const tableSchema = new mongoose.Schema({
    key: Number,
    state: String,
    paymentMethod: String,
    date: Date,
    value: Number,
    platform: String,
});

const Table = mongoose.model('Table', tableSchema);


module.exports = Table;