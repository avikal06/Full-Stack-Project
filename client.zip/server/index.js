const express = require("express");
const app = express();

const mongoose = require("mongoose");
// const { getMaxListeners } = require("./modules/Table");



mongoose.connect('mongodb://localhost:27017/tableData', {useNewUrlParser : true, useUnifiedTopology: true})
.then(()=>{
    console.log("Mongo Connection open");
})
.catch(()=>{
    console.log("OH NO MONGO CONNECTION ERROR");
})

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
    console.log("connection open")
});

const tableSchema = new mongoose.Schema({
    key: Number,
    state: String,
    paymentMethod: String,
    date: Date,
    value: Number,
    platform: String,
})


const Table = mongoose.model('Table', tableSchema);
// const row1 = new Table({key: '1',
// state: 'Complete',
// paymentMethod: 'Card',
// value: 100,
// date: '1 Jan 2024',
// platform: 'Amazon',})


Table.countDocuments({}, async (err, count) => {
    if (err) {
        console.error("Error counting table data:", err);
    } else {
        if (count === 0) {
            try {
                await Table.insertMany([
                    {
                        key: '1',
                        state: 'Complete',
                        paymentMethod: 'Card',
                        value: 100,
                        date: new Date('2024-01-01'),
                        platform: 'Amazon',
                    },
                    {
                        key: '2',
                        state: 'Complete',
                        paymentMethod: 'Card',
                        value: 50,
                        date: new Date('2024-01-01'),
                        platform: 'Netflix',
                    },
                    {
                        key: '3',
                        state: 'Canceled',
                        paymentMethod: 'Card',
                        value: 75,
                        date: new Date('2024-01-01'),
                        platform: 'Facebook',
                    },
                    {
                        key: '4',
                        state: 'Pending',
                        paymentMethod: 'Card',
                        value: 120,
                        date: new Date('2024-01-01'),
                        platform: 'Amazon Prime',
                    }
                ]);
                console.log("Table data inserted successfully");
            } catch (error) {
                console.error("Error inserting table data:", error);
            }
        } else {
            console.log("Table data already exists");
        }
    }
});
//routing

app.get("/table", async (req, res) => {
    try {
        const tableData = await Table.find({});
        res.json(tableData);
    } catch (error) {
        console.error("Error fetching table data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});







// new schema for recent visitors


const recentVisitorSchema = new mongoose.Schema({
    id: Number,
    img: String,
    name: String,
    email: String,
    amount: Number,
    city: String,

});

const recentCustomers = mongoose.model('recentCustomers', recentVisitorSchema);


const customers =[
    {
        id: 1,
        img: "/assets/Avikal.jpg",
        name: "Avikal Sinha",
        email: "haravikal06@gmail.com",
        amount: 11.234,
        city: "Noida"
    },
    {
        id: 2,
        img: "/assets/disha.png",
        name: "Disha Mishra",
        email: "dishamsr@gmail.com",
        amount: 11.234,
        city: "Kanpur"


    },
    {
        id: 3,
        img: "/assets/divyansh.png",
        name: "Divyansh Chawla",
        email: "dchawla01@.com",
        amount: 11.234,
        city: "Ghaziabad"

    },
    {
        id: 4,
        img: "/assets/mohil.jpg",
        name: "Mohil Chitransh",
        email: "mchitransh29@gmail.com",
        amount: 11.234,
        city: "Gurgaon"
    }
]
recentCustomers.countDocuments({}, async (err, count) => {
    if (err) {
        console.error("Error counting recent customers:", err);
    } else {
        if (count === 0) {
            try {
                await recentCustomers.insertMany(customers);
                console.log("Recent customers data inserted successfully");
            } catch (error) {
                console.error("Error inserting recent customers:", error);
            }
        } else {
            console.log("Recent customers data already exists");
        }
    }
});

    //endpoint


    app.get("/recent-customers", async (req, res) => {
    try {
        const recentCustomersData = await recentCustomers.find({});
        res.json(recentCustomersData);
    } catch (error) {
        console.error("Error fetching recent customers data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});



app.use((req, res)=>{
    console.log("we get a new  request!!");
    res.send({color: 'green'});
})

app.listen(3000, ()=>{
    console.log("Listening on port 3000!!");
})
